package com.example.duoihinhbatchu_v2.models;

import android.view.View;

public interface ItemListener {
    void onItemClick(View view, int position);
}
