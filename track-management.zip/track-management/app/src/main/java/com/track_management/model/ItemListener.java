package com.track_management.model;

import android.view.View;

public interface ItemListener {
    void onItemClick(View view, int position);
}
